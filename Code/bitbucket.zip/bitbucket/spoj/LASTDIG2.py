if __name__ == '__main__':
    t = int(raw_input())
    while (t):
        ab = raw_input()
        a = int(ab.split()[0])
        b = int(ab.split()[1])
        if a % 10 == 0:
            print 0
        else:
            print (a ** b) % 10
        t -= 1
