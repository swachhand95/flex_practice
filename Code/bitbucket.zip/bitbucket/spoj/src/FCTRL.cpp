#include <iostream>
#include <cmath>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cstring>

using namespace std;

#define MOD 1000000007LL
#define LL long long
#define ULL unsigned long long
#define LD long double
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define ABS(x) ((x)<0?-(x):(x))
#define si(n) scanf("%d",&n)
#define sf(n) scanf("%f",&n)
#define sl(n) scanf("%lld",&n)
#define slu(n) scanf("%llu",&n)
#define sd(n) scanf("%lf",&n)
#define ss(n) scanf("%s",n)
#define pnl printf("\n")
#define DB(x) cout<<"\n"<<#x<<" = "<<(x)<<"\n";

#define SIZE 1000001

int main()
{
    int t = 0;
    si(t);

    while (t--)
    {
        LL n = 0;
        sl(n);

        LL z = 0;
        for (LL i = 5; i <= n; i *= 5)
            z += n/i;

        printf("%lld\n", z);
    }

    return 0;
}


