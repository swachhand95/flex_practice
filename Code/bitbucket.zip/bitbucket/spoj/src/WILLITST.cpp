#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    long long n = 0;
    cin >> n;

    if ((n & (n - 1)) == 0)
        cout << "TAK" << endl;
    else 
        cout << "NIE" << endl;

    return 0;
}
