#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

#define SIZE 1001

int main()
{
    int t = 0;
    scanf("%d", &t);

    while (t--)
    {
        int n = 0;
        scanf("%d", &n);

        int men[SIZE] = {0};
        for (int i = 0; i < n; ++i)
            scanf("%d", &men[i]);
        sort(men, men + n);

        int women[SIZE] = {0};
        for (int i = 0; i < n; ++i)
            scanf("%d", &women[i]);
        sort(women, women + n);

        long long sum = 0;
        for (int i = 0; i < n; ++i)
            sum += men[i]*women[i];

        printf("%lld\n", sum);
    }

    return 0;
}

