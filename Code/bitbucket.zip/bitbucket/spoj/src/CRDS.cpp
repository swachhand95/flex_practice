#include <iostream>
#include <cstdio>

using namespace std;

#define MOD 1000007
#define SIZE 1000001

long long cards[SIZE] = {0};

int main()
{
    int t = 0;
    scanf("%d", &t);

    cards[1] = 2;
    for (int i = 2; i < SIZE; ++i)
        cards[i] = cards[i - 1] + i * 2 + (i - 1);

    while (t--)
    {
        long long lvl = 0;
        scanf("%lld", &lvl);

        long long crds = cards[lvl];
        crds %= MOD;
        printf("%lld\n", crds);
    }

    return 0;
}
