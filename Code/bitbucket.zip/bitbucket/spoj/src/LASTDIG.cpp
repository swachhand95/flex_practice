#include <iostream>
using namespace std;

int modExp(int a, int b, int mod)
{
    if (b == 1)
        return a % mod;
    if (b == 0)
        return 1;
    if (a == 0)
        return 0;

    int num1 = modExp(a, b/2, mod);
    int num2 = 0;
    if (b % 2 == 0)
        num2 = num1;
    else
        num2 = modExp(a, b/2 + 1, mod);

    return (num1 * num2) % mod;
}

int main()
{
    int t = 0;
    scanf("%d", &t);

    while (t--)
    {
        int a = 0;
        int b = 0;
        scanf("%d%d", &a, &b);

        int ans = modExp(a, b, 10);
        printf("%d\n", ans);
    }

    return 0;
}
