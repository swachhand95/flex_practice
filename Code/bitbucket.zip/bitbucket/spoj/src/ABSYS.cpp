#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>

using namespace std;

#define SIZE 12

inline bool find_machula(char *str)
{
    int sz = strlen(str);
    for (int i = 0; i < sz; ++i)
        if (str[i] == 'm')
            return true;
    return false;
}

int main()
{
    int t = 0;
    scanf("%d", &t);

    while (t--)
    {
        char a[SIZE] = {0};
        char b[SIZE] = {0};
        char sum[SIZE] = {0};

        scanf("%s + %s = %s", a, b, sum);

        int x = 0, y = 0, z = 0; 
        if (find_machula(a))
        {
            y = atoi(b);
            z = atoi(sum);
            x = z - y;
        }
        else if (find_machula(b))
        {
            x = atoi(a);
            z = atoi(sum);
            y = z - x;
        }
        else
        {
            x = atoi(a);
            y = atoi(b);
            z = x + y;
        }

        printf("%d + %d = %d\n", x, y, z);
    }

    return 0;
}
