#include <iostream>
#include <vector>
#include <queue>

using namespace std;

typedef vector<vector<int> > Graph;

int bfs(int s, const Graph &G, int &d)
{
    int n = G.size();
    vector<bool> disc(n);
    vector<int> dist(n);

    queue<int> q;
    q.push(s);

    int furthest = s;

    while (!q.empty())
    {
        int u = q.front();
        q.pop();
        furthest = u;
        for (auto v : G[u])
        {
            if (!disc[v])
            {
                disc[v] = true;
                dist[v] = dist[u] + 1; 
                q.push(v);
            }
        }
    }
    
    d = dist[furthest];
    return furthest;
}

int main()
{
    int n = 0;
    scanf("%d", &n);

    Graph G(n + 1);

    for (int i = 0; i != n - 1; ++i)
    {
        int u = 0, v = 0;
        scanf("%d%d", &u, &v);
        
        G[u].push_back(v);
        G[v].push_back(u);
    }
    
    int max_dist = 0;
    int u = bfs(1, G, max_dist);
    bfs(u, G, max_dist);

    printf("%d\n", max_dist);

    return 0;
}
