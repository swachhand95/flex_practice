#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>

int main()
{
    std::ios::sync_with_stdio(false);

    int t = 0;
    std::cin >> t;

    for (int sc = 0; sc != t; ++sc)
    {
        long long int need = 0;
        int friends = 0;

        std::cin >> need >> friends;
        std::vector<int> stamps(friends);

        for (int i = 0; i < friends; ++i)
            std::cin >> stamps[i];

        std::sort(stamps.rbegin(), stamps.rend());
        
        int min = 0;
        for (auto n : stamps)
        {
            if (need <= 0) break;

            if (need >= n)
                need -= n;
            else 
                need = 0;

            ++min;
        }

        std::cout << "Scenario #" << sc + 1 << ":\n";
        if (need <= 0)
            std::cout << min << "\n\n";
        else
            std::cout << "impossible\n\n";
    }

    return 0;
}
