#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    long long n = 0;
    scanf("%lld", &n);

    int first_move = n % 10;
    int winner = 1;

    if (first_move == 0) winner = 2;

    printf("%d\n", winner);
    if (winner == 1) printf("%d\n", first_move);

    return 0;
}
