#include <iostream>
#include <cstdio>
using namespace std;

long long int reverse(long long int num) {
	long long int rev = 0;

    while (num % 10 == 0)
        num /= 10;
	
	while (num != 0)
	{
        rev *= 10;
        rev += num % 10;
        num /= 10;
	}
	
	return rev;
}
int main() {
	
	// your code here
	int t = 0;
	scanf("%d", &t);

	while (t--)
	{
		long long int a = 0, b = 0;
		scanf("%lld %lld", &a, &b);
		
		long long int res = reverse(a);
		res += reverse(b);
		res = reverse(res);
		
		printf("%lld\n", res);
	}

	return 0;
}
