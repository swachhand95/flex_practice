#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdio>
#include <cmath>

#define PR(X) std::cout << "[" << #X << " = " << (X) << "]" << std::endl

using namespace std;

int main()
{
    int t = 0;
    scanf("%d", &t);

    for (int i = 1; i <= t; ++i)
    {
        // Your code goes here
        double r = 0;
        scanf("%lf", &r);

        double r_sq = r * r;
        double x = (1 - 8 * r_sq) / (8 * r);

        double s = 2 * r_sq - 2 * x * r + sqrt(2 * r_sq + 2 * x * r);
        
        printf("Case %d: %0.2lf\n", i, s);
    }
}
