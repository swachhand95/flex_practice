#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdio>

#define PR(X) std::cout << "[" << #X << " = " << (X) << "]" << std::endl

using namespace std;

int main()
{
    int l = 0;
    scanf("%d", &l);

    while (l)
    {
        double area = 0;
        area = (l * l) / (2 * 3.1415926);
        printf("%0.2f\n", area);
        scanf("%d", &l); 
    }
}
