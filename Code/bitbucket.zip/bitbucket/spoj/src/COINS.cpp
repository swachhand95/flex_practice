#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    int t = 10;
    while (t--)
    {
        long long int n = 0;
        scanf("%lld", &n);

        long long int sum = n/2 + n/3 + n/4;
        if (sum > n)
            printf("%lld\n", sum);
        else
            printf("%lld\n", n);
    }

}
