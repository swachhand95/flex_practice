#include <iostream>
#include <vector>

using namespace std;

class UF
{
    public:
        UF(int n);
        void connect(int a, int b);
        bool connected(int a, int b);
        bool allConnected();
    private:
        vector<int> id;
        vector<int> sz;
        int root(int x);
};

UF::UF(int n) : id(n + 1), sz(n + 1)
{
    for (int i = 1; i <= n; ++i)
    {
        id[i] = i;
        sz[i] = 1;
    }
}

int UF::root(int x)
{
    while (id[x] != x)
        x = id[x];
    int p = x;
    while (id[x] != x)
    {
        x = id[x];
        id[x] = p;
    }
    return x;
}

bool UF::connected(int a, int b)
{
    return root(a) == root(b);
}

void UF::connect(int a, int b)
{
    int aid = id[a];
    int bid = id[b];

    if (sz[aid] < sz[bid])
    {
        id[a] = id[b];
        sz[bid] += sz[aid];
    }
    else
    {
        id[b] = id[a];
        sz[aid] += sz[bid];
    }
}

bool UF::allConnected() 
{
    int p = root(1);
    for (size_t i = 2; i < id.size(); ++i)
       if (p != root(i))
          return false;
   return true; 
}

int main()
{
    int n = 0, m = 0;
    scanf("%d%d", &n, &m);

    UF unionFind(n);

    int i = 0;
    for (; i < m; ++i)
    {
        int a = 0, b = 0;
        scanf("%d%d", &a, &b);

        if (unionFind.connected(a, b))
            break;
        else
            unionFind.connect(a, b);
    }

    if (i < m || !unionFind.allConnected())
        printf("NO\n");
    else
        printf("YES\n");

    return 0;
}
