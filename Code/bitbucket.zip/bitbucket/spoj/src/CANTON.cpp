#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    int t = 0;
    scanf("%d", &t);

    while(t--)
    {
        long long n = 0;
        scanf("%lld", &n);

        long long i = 1, j = 1, idx = 1;
        while(idx < n)
        {
            if (i == 1 && (j & 1))
            {
                ++j;
                ++idx;
            }
            else if (i == 1 && !(j & 1))
            {
                while (idx < n && j != 1)
                {
                    ++i;
                    --j;
                    ++idx;
                }
            } 
            else if (j == 1 && !(i & 1))
            {
                ++i;
                ++idx;
            }
            else if (j == 1 && (i & 1))
            {
                while (idx < n && i != 1)
                {
                    --i;
                    ++j;
                    ++idx;
                }
            }
        }

        printf("TERM %lld IS %lld/%lld\n", n, i, j);
    } 
}
