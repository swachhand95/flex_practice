#include <iostream>

using namespace std;

/*
 *  Multiplies a large integer of arbitrary length by an integer b and
 *  stores the result in the array a
 */
int multiply(int a[], int digits, int b)
{
    int temp = 0;
    for (int i = 0; i < digits; ++i)
    {
        int x = a[i] * b + temp;
        temp = x / 10;
        a[i] = x % 10;
    }

    while (temp)
    {
        a[digits++] = temp % 10;
        temp /= 10;
    }

    return digits;
}

void printArr(int arr[], int sz)
{
    while (sz--)
        cout << arr[sz];
    cout << endl;
}

void test()
{
    int a[200] = {5, 4};
    int sz = multiply(a, 2, 37);
    printArr(a, sz);
}

int main()
{
    int t = 0;
    scanf("%d", &t);

    while (t--)
    {
        int n = 0;
        scanf("%d", &n);

        int a[200] = {1};
        int digits = 1;

        for (int i = 2; i <= n; ++i)
            digits = multiply(a, digits, i);

        printArr(a, digits);
    }

    return 0;
}
