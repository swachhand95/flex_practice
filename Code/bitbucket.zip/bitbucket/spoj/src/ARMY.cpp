#include <iostream>
#include <vector>
#include <cstdio>
#include <algorithm>

using namespace std;

int main()
{
    int t = 0;
    scanf("%d", &t);


    while (t--)
    {
        int ng = 0, nm = 0;
        scanf("%d%d", &ng, &nm);

        vector<int> g_army(ng);
        vector<int> mg_army(nm);

        for (int i = 0; i < ng; ++i)
            scanf("%d", &g_army[i]);
        for (int i = 0; i < nm; ++i)
            scanf("%d", &mg_army[i]);

        sort(g_army.begin(), g_army.end());
        sort(mg_army.begin(), mg_army.end());

        int i = 0, j = 0;
        while (i < ng && j < nm)
            if (g_army[i] < mg_army[j])
                i++;
            else 
                j++;

        if (i < ng)
            printf("Godzilla\n");
        else if (j < nm)
            printf("MechaGodzilla\n");
    }
}
