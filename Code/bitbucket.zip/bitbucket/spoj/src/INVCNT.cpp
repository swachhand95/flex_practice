#include <iostream>
#include <cstdio>

using namespace std;

#define LL long long
#define SIZE 200005

LL merge(LL a[] , LL low, LL mid, LL high)
{
    LL n1 = mid - low + 1;
    LL *l = new LL[n1];
    for (LL i = 0, j = low; i < n1 && j <= high; ++i, ++j)
        l[i] = a[j];

    LL n2 = high - mid;
    LL *r = new LL[n2];
    for (LL i = 0, j = mid + 1; i < n1 && j <= high; ++i, ++j)
        r[i] = a[j];

    LL i = 0, j = 0, k = low;
    LL inv = 0;

    while (i < n1 && j < n2 && k <= high)
    {
        if (l[i] < r[j])
        {
            a[k++] = l[i++];
        }
        else
        {
            a[k++] = r[j++];
            inv += (n1 - i);
        }
    }

    while (i < n1 && k <= high)
        a[k++] = l[i++];
    while (i < n2 && k <= high)
        a[k++] = r[j++];

    delete []l;
    delete []r;

    return inv;
}

LL countInvAndSort(LL a[], LL low, LL high)
{
    if (low >= high) return 0;

    LL mid = (high - low) / 2 + low;
    LL inv = countInvAndSort(a, low, mid) +
        countInvAndSort(a, mid + 1, high) +
        merge(a, low, mid, high);
    return inv;
}

int main()
{
    int t = 0;
    scanf("%d", &t);

    LL a[SIZE] = {0};

    while (t--)
    {
        LL n = 0;
        scanf("%lld", &n);

        for (LL i = 0; i < n; ++i)
            scanf("%lld", &a[i]);

        LL inv = countInvAndSort(a, 0, n - 1);
        printf("%lld\n", inv);
    }

    return 0;
}
