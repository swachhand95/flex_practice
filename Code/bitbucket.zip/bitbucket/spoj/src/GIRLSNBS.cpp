#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    int g = 0, b = 0;
    scanf("%d%d", &g, &b);

    while (g != -1 && b != -1)
    {
        int max = g > b ? g : b;
        int min = g > b ? b : g;
        int ans = max;
        if (min)
        {
            ans = max / (min + 1);
            if (max % (min + 1)) 
            {
                ans++;
            }
        }
        printf("%d\n", ans);
        scanf("%d%d", &g, &b);
    }

    return 0;
}
