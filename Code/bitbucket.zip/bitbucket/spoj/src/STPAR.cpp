#include <iostream>
#include <vector>
#include <stack>
#include <cstdio>

using namespace std;

int main()
{
    int trucks = 0;
    scanf("%d", &trucks);

    while (trucks)
    {
        stack<int> side_lane;
        vector<int> order(trucks);

        for (int i = 0; i < trucks; ++i)
            scanf("%d", &order[i]);

        int next = 1;
        int i = 0;
        while (i < trucks)
        {
            if (!side_lane.empty() && next == side_lane.top())
            {
                ++next;
                side_lane.pop();
            }
            else if (next != order[i])
            {
                side_lane.push(order[i]);
                ++i;
            }
            else if (next == order[i])
            {
                ++next;
                ++i;
            }
        }
        while (!side_lane.empty())
        {
            if (next != side_lane.top()) break;
            else
            {
                ++next;
                side_lane.pop();
            }
        }

        if (side_lane.empty())
            printf("yes\n");
        else printf("no\n");

        scanf("%d", &trucks);
    }

    return 0;
}
