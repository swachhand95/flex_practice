#include <iostream>
#include <cstdio>
#include <string>
#include <vector>

using namespace std;

#define SIZE 100005

int main()
{
    int n = 0;
    int a[SIZE] = {0};
    while (true)
    {
        scanf("%d", &n);
        if (!n) break;
        
        for (int i = 1; i <= n; ++i)
            scanf("%d", &a[i]);
        
        int i = 0;
        for (i = 1; i <= n; ++i)
        {
            int el = a[i];
            if (a[el] != i)
                break; 
        }
        
        if (i != n + 1)
            printf("not ambiguous\n");
        else
            printf("ambiguous\n"); 
    } 

    return 0;
}
