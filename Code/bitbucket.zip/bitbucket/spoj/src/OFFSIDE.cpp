#include <iostream>
#include <vector>
#include <cstdio>
#include <algorithm>

using namespace std;

int main()
{
    int a = 0, d = 0;
    scanf("%d%d", &a, &d);

    while (a != 0 and d != 0)
    {
        vector<int> atk(a);
        vector<int> def(d); 

        for (int i = 0; i != a; ++i)
            scanf("%d", &atk[i]);
        for (int i = 0; i != d; ++i)
            scanf("%d", &def[i]);

        sort(atk.begin(), atk.end());
        sort(def.begin(), def.end());

        bool offside = false;
        for (size_t i = 0; i < 2 && i < def.size(); ++i)
        {
            for (size_t j = 0; j < atk.size(); ++j)
            {
                if (atk[j] < def[i])
                {
                    offside = true;
                    break;
                }
            }
        }

        if (offside) printf("Y\n");
        else printf("N\n");

        scanf("%d%d", &a, &d);
    }

    return 0;
}
