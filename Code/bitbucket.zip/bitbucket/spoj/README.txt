Repository for my accepted SPOJ submissions
