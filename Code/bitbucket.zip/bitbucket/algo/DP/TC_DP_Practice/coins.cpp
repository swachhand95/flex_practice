#include <iostream>
#include <vector>
#include <limits>

using namespace std;

int minCoinsRecursive(const vector<int> &v, int sum)
{
    if (sum <= 0)
        return 0;

    int min = -1;
    for (size_t r = 0; r < v.size(); ++r)
    {
        int coins = minCoinsRecursive(v, sum - v[r]) + 1;
        if (coins < min || min == -1)
            min = coins;
    }

    return min;
}

int minCoinsMemoized(const vector<int> &v, int i)
{
    static const int INF = numeric_limits<int>::max();
    static vector<int> A(i + 1, INF);

    if (i <= 0) return 0;
    if (A[i] != INF) return A[i];

    for (size_t r = 0; r < v.size(); ++r)
    {
        if (i >= v[r])
            A[i] = std::min(A[i], minCoinsMemoized(v, i - v[r]) + 1);
    }

    return A[i];
}

int main()
{
    vector<int> v = {1, 3, 5};
    int sum = 11;

    cout << minCoinsRecursive(v, sum) << endl;
    cout << minCoinsMemoized(v, sum) << endl;

    return 0;
}
