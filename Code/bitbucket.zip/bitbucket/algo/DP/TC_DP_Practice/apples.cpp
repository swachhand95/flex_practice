#include <iostream>
#include <vector>

using namespace std;

int maxApplesRecursive(const vector<vector<int>> &A, size_t i, size_t j);
int maxApplesMemoized(const vector<vector<int>> &A, size_t i, size_t j);
int maxApplesTopDown(const vector<vector<int>> &A);

int main()
{
    vector<vector<int> > A = {{1 , 2, 3}, 
                              {4 , 2, 1},
                              {32, 1, 6}};

    cout << maxApplesRecursive(A, 0, 0) << endl;
    cout << maxApplesMemoized(A, 0, 0) << endl;
    cout << maxApplesTopDown(A) << endl;

    return 0;
}

int maxApplesRecursive(const vector<vector<int>> &A, size_t i, size_t j)
{
    size_t N = A.size();
    size_t M = A[0].size();

    if (i >= N || j >= M) return 0;

    return std::max(maxApplesRecursive(A, i + 1, j),
                    maxApplesRecursive(A, i, j + 1)) + A[i][j];
}

int maxApplesMemoized(const vector<vector<int>> &A, size_t i, size_t j)
{
    size_t N = A.size();
    size_t M = A[0].size();

    static vector<vector<int>> V(N, vector<int>(M, -1));

    if (i >= N || j >= M) return 0;
    if (V[i][j] != -1) return V[i][j];
    
    V[i][j] = std::max(maxApplesMemoized(A, i + 1, j),
                       maxApplesMemoized(A, i, j + 1)) + A[i][j];
    return V[i][j];
}

int maxApplesTopDown(const vector<vector<int>> &A)
{
    size_t N = A.size();
    size_t M = A[0].size();
    
    // V[i][j] = max number of apples for matrix of size i x j
    vector<vector<int>> V(N + 1, vector<int>(M + 1));
    V[0][0] = 0;

    for (size_t i = 1; i <= N; ++i)
    {
        for (size_t j = 1; j <= M; ++j)
        {
            V[i][j] = A[i - 1][j - 1] + std::max(V[i - 1][j], V[i][j - 1]);
        }
    }

    return V[N][M];
}
